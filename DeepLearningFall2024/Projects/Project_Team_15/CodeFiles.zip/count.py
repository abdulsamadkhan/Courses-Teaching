import json

def count_qa_pairs(json_file):
    with open(json_file, 'r', encoding='utf-8') as file:
        data = json.load(file)
    count = len(data)
    return count
json_file = 'qa_data.json'
qa_count = count_qa_pairs(json_file)
#json_file2 = 'junejo_data.json'
#qa_count2 = count_qa_pairs(json_file)
#qa_count = qa_count + qa_count2
print(f"The number of question-answer pairs in the file is: {qa_count}")
