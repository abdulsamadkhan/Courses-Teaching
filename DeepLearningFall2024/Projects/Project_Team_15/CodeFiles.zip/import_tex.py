import json
import re

def extract_qa_pairs_from_latex(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
    
    # Split content into lines for easier line-by-line parsing
    lines = content.splitlines()
    qa_pairs = []
    expected_pairs = 732

    question, answer = None, []
    in_answer = False
    in_itemize_block = False

    for line in lines:
        # Detect a new question line
        if "\\textbf{Question:}" in line:
            # Save the previous question-answer pair if exists
            if question and answer:
                qa_pairs.append({
                    "question": question.strip(),
                    "answer": " ".join(answer).strip()
                })
                question, answer = None, []  # Reset for the next Q/A pair
            # Extract question content
            question = re.sub(r'\\textbf{Question:}', '', line).strip()
            in_answer = False
        
        # Detect an answer line
        elif "\\textbf{Answer:}" in line:
            # Extract answer content and start answer recording
            answer.append(re.sub(r'\\textbf{Answer:}', '', line).strip())
            in_answer = True
        
        # If in an answer block, keep appending lines to answer
        elif in_answer:
            # Check for the beginning of an itemize block
            if "\\begin{itemize}" in line:
                in_itemize_block = True
                answer.append(line.strip())
            # Check for the end of an itemize block
            elif "\\end{itemize}" in line:
                in_itemize_block = False
                answer.append(line.strip())
            # If in an itemize block, add all lines (including \item lines)
            elif in_itemize_block:
                answer.append(line.strip())
            # If outside itemize block, end answer on \item or \end{enumerate}
            elif "\\item" in line or "\\end{enumerate}" in line:
                in_answer = False
            else:
                answer.append(line.strip())
    
    # Capture the last question-answer pair if any
    if question and answer:
        qa_pairs.append({
            "question": question.strip(),
            "answer": " ".join(answer).strip()
        })

    # Validation message
    if not qa_pairs:
        print("Warning: No Q/A pairs found. Check if LaTeX formatting matches the expected structure.")
    elif len(qa_pairs) != expected_pairs:
        print(f"Warning: Expected {expected_pairs} pairs, but found {len(qa_pairs)}.")

    return qa_pairs

def save_to_json(data, output_file):
    # Save the extracted data as a JSON file
    with open(output_file, 'w', encoding='utf-8') as json_file:
        json.dump(data, json_file, indent=4, ensure_ascii=False)

def clean_qa_data(qa_data):
    cleaned_data = []
    
    for entry in qa_data:
        # Clean question
        question = entry['question']
        question = re.sub(r'\\item\s*', '', question)  # Remove \item at the start
        question = re.sub(r'\\\\', '', question)       # Remove line breaks (\\)
        question = question.strip()                    # Trim any remaining whitespace
        
        # Clean answer
        answer = entry['answer']
        answer = re.sub(r'\\\\', '', answer)           # Remove line breaks (\\)
        answer = re.sub(r'\\begin{itemize}', '', answer)  # Remove \begin{itemize}
        answer = re.sub(r'\\end{itemize}', '', answer)    # Remove \end{itemize}
        answer = re.sub(r'\\begin{enumerate}', '', answer) # Remove \begin{enumerate}
        answer = re.sub(r'\\end{enumerate}', '', answer)   # Remove \end{enumerate}
        answer = re.sub(r'\\item\s*', '', answer)       # Remove \item from within answers
        answer = answer.strip()                         # Trim any remaining whitespace

        # Append cleaned data
        cleaned_data.append({
            "question": question,
            "answer": answer
        })
    
    return cleaned_data



input_file = 'Compilations/QNA.tex'  # Correct file path for accessing QNA.tex
output_file = 'qa_data.json'  # Output JSON file path

qa_data = extract_qa_pairs_from_latex(input_file)
cleaned_qa_data = clean_qa_data(qa_data)

#save_to_json(qa_data, output_file)
save_to_json(cleaned_qa_data, output_file)


print(f"Q/A data has been saved to {output_file}")
