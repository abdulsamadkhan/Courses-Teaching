def create_train_dataset(incorrect_file, correct_file):
    # Read both files
    with open(incorrect_file, 'r', encoding='utf-8') as file:
        incorrect_lines = file.readlines()
    
    with open(correct_file, 'r', encoding='utf-8') as file:
        correct_lines = file.readlines()
    
    # Ensure both files have the same number of lines
    if len(incorrect_lines) != len(correct_lines):
        raise ValueError("The number of lines in the incorrect and correct files do not match.")
    
    # Create the train_dataset
    train_dataset = []
    for i in range(len(incorrect_lines)):
        input_text = "جملے کی درستگی: " + incorrect_lines[i].strip()
        output_text = correct_lines[i].strip()
        
        train_dataset.append({"input": input_text, "output": output_text})
    
    return train_dataset

# Example usage
incorrect_file_path = 'sampled_augmented_incorrect.txt'  # Replace with your file path
correct_file_path = 'sampled_augmented_correct.txt'  # Replace with your file path

# Create the dataset using all sentences
train_dataset = create_train_dataset(incorrect_file_path, correct_file_path)

# Print the first 5 examples
print(f"Created {len(train_dataset)} training examples.\n")
for example in train_dataset[:5]:
    print(f"Input: {example['input']}")
    print(f"Output: {example['output']}")
    print("-" * 40)
