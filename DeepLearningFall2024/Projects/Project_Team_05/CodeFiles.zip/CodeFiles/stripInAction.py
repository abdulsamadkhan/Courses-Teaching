def read_file_with_strip_demo(file_path, num_sentences=5):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    
    print(f"Reading the first {num_sentences} lines from the file...\n")
    
    for i, line in enumerate(lines[:num_sentences]):
        print(f"Line {i + 1} before .strip(): '{line}'")
        stripped_line = line.strip()
        print(f"Line {i + 1} after .strip():  '{stripped_line}'\n")
        
        # Show differences if any
        if line != stripped_line:
            print(f"--> Difference detected! Whitespace or newlines were removed.")
        else:
            print(f"--> No changes made by .strip().")
        print("-" * 40)

# Example usage
file_path = 'sampled_augmented_correct.txt'  # Replace with the path to your .txt file
read_file_with_strip_demo(file_path, num_sentences=5)
