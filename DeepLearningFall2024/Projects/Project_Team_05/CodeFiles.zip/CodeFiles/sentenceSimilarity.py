def compare_text_files(file1_path, file2_path, num_sentences):
    """
    Compares the top N sentences from two text files.
    
    :param file1_path: Path to the first text file.
    :param file2_path: Path to the second text file.
    :param num_sentences: Number of sentences to compare from the top of each file.
    """
    try:
        # Read the files
        with open(file1_path, 'r', encoding='utf-8') as file1, open(file2_path, 'r', encoding='utf-8') as file2:
            # Read lines
            file1_sentences = file1.readlines()
            file2_sentences = file2.readlines()
            
            # Truncate to the specified number of sentences
            file1_sentences = file1_sentences[:num_sentences]
            file2_sentences = file2_sentences[:num_sentences]
            
            # Compare sentences
            for i in range(num_sentences):
                if i >= len(file1_sentences) or i >= len(file2_sentences):
                    print(f"Index {i}: One of the files has fewer sentences.")
                    continue

                sentence1 = file1_sentences[i].strip()
                sentence2 = file2_sentences[i].strip()
                if sentence1 == sentence2:
                    print(f"Index {i}: Sentences are the same.")
                else:
                    print(f"Index {i}: Sentences are different.")
                    print(f"File 1: {sentence1}")
                    print(f"File 2: {sentence2}")
                    
    except FileNotFoundError as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Example usage
file1_path = "sampled_augmented_correct.txt"
file2_path = "sampled_augmented_incorrect.txt"
num_sentences = 5  # Adjust the number of sentences to compare
compare_text_files(file1_path, file2_path, num_sentences)
